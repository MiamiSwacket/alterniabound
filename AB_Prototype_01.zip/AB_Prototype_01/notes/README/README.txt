The fonts "m3x6" and "m5x7" are made by Daniel Linssen / @managore and shared under the CC0 v1.0 license.
At time of writing they are free to use but attribution is appreciated.
They were last available here along with Daniel's other works: https://managore.itch.io/